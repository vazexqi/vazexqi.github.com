//
//  main.m
//  flickrPreviewR
//
//  Created by Nicholas Chen on 7/16/07.
//  Copyright (c) 2007 __MyCompanyName__. All rights reserved.
//

#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
