#
#  NotificationMessages.rb
#  flickrViewer2
#
#  Created by Nicholas Chen on 7/13/07.
#  Copyright (c) 2007 __MyCompanyName__. All rights reserved.
#

module NotificationMessages
	RELOAD_IMAGE_PREVIEW = 'reload_image_preview'.freeze
	RELOAD_IMAGE_VIEW = 'reload_image_view'.freeze
	DELETE_FAVORITE_RELOAD = 'delete_favorite_reload'.freeze
	BLANK_IMAGE_RELOAD = 'blank_image_reload'.freeze
	DOWNLOADING_INDICATOR = 'downloading_indicator'.freeze
end
